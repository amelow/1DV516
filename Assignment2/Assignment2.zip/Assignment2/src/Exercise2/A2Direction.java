package Exercise2;

public enum A2Direction {

    UP,
    RIGHT,
    DOWN, 
    LEFT
    
}
