package Exercise1;

public interface A2HashTable<T> {

    public void insert(T element);
    
    public void delete(T element);

    public boolean contains(T element);
    
    public int getLengthOfArray();
}
