package Exercise3;

public interface A2Measure {

	public boolean isSameCollection(int[] array1, int[] array2);

	public int minDifferences(int[] array1, int[] array2);

	public int[] getPercentileRange(int[] arr, int lower, int upper);
}
