package Exercise2;

public interface A1SequenceWithMinimum {
	
	public void insertRight(Integer value);

	public Integer removeRight();

	public void insertLeft(Integer value);

	public Integer removeLeft();

	public Integer findMinimum();
}
