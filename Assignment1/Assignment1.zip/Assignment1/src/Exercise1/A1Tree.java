package Exercise1;
/*
 * The tree interface A1Tree was included in the assignment description
 */

public interface A1Tree {

	public void insert(Integer value); 

	public Integer mostSimilarValue(Integer value);

	public void printByLevels();
}
